    <?php get_header(); ?>
    <div class="contain">

      <div class="row">

        <?php 
      if ( have_posts() ) : while ( have_posts() ) : the_post();
    
        get_template_part( 'content', get_post_format() );
  
      endwhile; endif; 
      ?>

        
      <?php wp_link_pages( array(
        'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'terrain' ) . '</span>',
        'after'       => '</div>',
        'link_before' => '<span>',
        'link_after'  => '</span>',
        ) );
?>
        </div><!-- /.blog-main -->

        
      <?php get_footer(); ?>
      </div><!-- /.row -->
      
