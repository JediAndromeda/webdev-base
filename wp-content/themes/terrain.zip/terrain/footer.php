

    <footer class="blog-footer">
      <div class="foot">Blog template by <a href="$madeby">Me!</a>

    </div><!-- foot -->
      


    </footer>

  </body>
</html>