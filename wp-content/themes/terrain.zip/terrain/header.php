<!DOCTYPE html>
<html lang="en" <?php language_attributes(); ?>>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">


    
  <?php wp_head();?>
  </head>

  <body <?php body_class(); ?>>

    
      <div class="navbar">
        
      
    

    <div class="blog-header">
      <div class="container">
        <h1 class="blog-title"><a href="<?php echo site_url( 'wpurl' );?>"><?php echo get_bloginfo( 'name' ); ?></a></h1>
        
        <p class="lead blog-description"><?php echo get_bloginfo( 'description' ); ?></p>
      </div> <!-- /.container -->
    </div> <!-- /.blog-header -->
    <?php get_sidebar(); ?>
    </div> <!-- /.navbar -->